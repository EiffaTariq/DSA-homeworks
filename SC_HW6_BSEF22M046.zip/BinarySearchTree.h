#include<iostream>
#include"TreeNode.h"
#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H
class BinarySearchTree
{
public:
    Treenode* root;
    BinarySearchTree();
    Treenode* insert(Treenode* root,int x);
    void inOrder(Treenode* root);
    void preOrder(Treenode* root);
    void postOrder(Treenode* root);
    Treenode* deleteNode(Treenode* root, int x);
    Treenode* getSuccessor(Treenode* c);
    Treenode* search(Treenode* node, int value);
    void sumAtEachLevel(int tree[], int size);
    Treenode* findMin(Treenode* node);
    Treenode* findMax(Treenode* node);
    int findHeight(Treenode* root);
    void printTree(Treenode* root, int space,int count);
};
#endif