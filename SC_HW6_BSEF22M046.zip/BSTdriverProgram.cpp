#include<iostream>
#include"BinarySearchTree.h"
using namespace std;
int main()
{
	BinarySearchTree b;
	Treenode* root = b.insert(b.root,14);
	b.insert(root,7);        
	b.insert(root,17);
	b.insert(root,4);     
	b.insert(root,12);     
	b.insert(root,11);     
	b.insert(root,13);    
	b.insert(root,8);      
	b.insert(root,53); 
	b.preOrder(root);
	cout << endl;
	cout << "deleting element 4 from the tree\n";
	b.deleteNode(root, 4);
	b.preOrder(root);
	cout << endl;
	cout << "deleting element 12 from the tree\n";
	b.deleteNode(root, 12);
	b.preOrder(root);
	cout << endl;
	b.deleteNode(root, 60);
	b.preOrder(root);
	cout << endl;
	cout << b.findHeight(root);
	return 0;


	/*   14
	    /  \
	   7    17
	  / \     \
	 4  12    53
	    / \
	   11  13
	   /
	   8
	*/
}