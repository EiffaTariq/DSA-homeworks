#include<iostream>
#ifndef TREENODE_H
#define TREENODE_H
class Treenode
{
public:
    int data;
    Treenode* left;
    Treenode* right;
    Treenode(int value) : data(value), left(nullptr), right(nullptr) {}
};
#endif