//#include<iostream>
//#include<iomanip>
//#include"BinarySearchTree.h"
//#include"TreeNode.h"
//using namespace std;
//BinarySearchTree::BinarySearchTree()
//{
//	root = NULL;
//}
//Treenode* BinarySearchTree::insert(Treenode*root,int x)
//{
//	//iterative
//
//	/*Treenode* n1 = new Treenode(x);
//	if (root == NULL)
//	{
//		root = n1;
//	}
//	else
//	{
//		Treenode* p = NULL;
//		Treenode* temp = root;
//		while (temp != NULL)
//		{
//			p = temp;
//			if (x < temp->data)
//			{
//				temp = temp->left;
//			}
//			else
//			{
//				temp = temp->right;
//			}
//		}
//		if (x < p->data)
//		{
//			p->left = n1;
//		}
//		else
//		{
//			p->right = n1;
//		}
//	}
//	return n1;*/
//
//	//recursive
//	if (root == NULL)
//	{
//		return new Treenode(x);
//	}
//	if (x >= root->data)
//	{
//		root->right = insert(root->right, x);
//	}
//	else
//	{
//		root->left = insert(root->left, x);
//	}
//	return root;
//}
//
//Treenode* BinarySearchTree::search(Treenode* node, int value)
//{
//	if (node == nullptr || node->data == value)
//	{
//		return node;
//	}
//
//	if (value < node->data)
//	{
//		return search(node->left, value);
//	}
//	else
//	{
//		return search(node->right, value);
//	}
//}
//
//Treenode* BinarySearchTree::findMin(Treenode* node)
//{
//	while (node->left != nullptr)
//	{
//		node = node->left;
//	}
//	return node;
//}
//
//Treenode* BinarySearchTree::findMax(Treenode* node)
//{
//	while (node->right != nullptr)
//	{
//		node = node->right;
//	}
//	return node;
//}
//
//Treenode* BinarySearchTree::deleteNode(Treenode*root,int x)
//{
//
//	//iterativce
//	if (root == nullptr)
//	{
//		return root;
//	}
//
//	if (search(root, x) == 0)
//	{
//		cout << "value does not exist\n";
//		return root;
//	}
//
//	Treenode* parent = nullptr;
//	Treenode* curr = root;
//
//	while (curr != nullptr && curr->data != x)
//	{
//		parent = curr;
//		if (x < curr->data)
//		{
//		curr = curr->left;
//		}
//		else 
//		{
//			curr = curr->right;
//		}
//	}
//
//	if (curr == nullptr)
//	{
//		return root;
//	}
//
//	if (curr->left == nullptr)
//	{
//		if (parent == nullptr)
//		{
//			root = curr->right;
//		}
//		else if (parent->left == curr)
//		{
//			parent->left = curr->right;
//		}
//		else
//		{
//			parent->right = curr->right;
//		}
//		delete curr;
//	}
//	else if (curr->right == nullptr)
//	{
//		if (parent == nullptr)
//		{
//			root = curr->left;
//		}
//		else if (parent->left == curr)
//		{
//			parent->left = curr->left;
//		}
//		else
//		{
//			parent->right = curr->left;
//		}
//		delete curr;
//	}
//	else
//	{
//		Treenode* successor = curr->right;
//		Treenode* successorParent = curr;
//		while (successor->left != nullptr)
//		{
//			successorParent = successor;
//			successor = successor->left;
//		}
//		if (successorParent != curr)
//		{
//			successorParent->left = successor->right;
//			successor->right = curr->right;
//		}
//		if (parent == nullptr) 
//		{
//			root = successor;
//		}
//		else if (parent->left == curr)
//		{
//			parent->left = successor;
//		}
//		else
//		{
//			parent->right = successor;
//		}
//		successor->left = curr->left;
//		delete curr;
//	}
//
//	return root;
//
//	//recursive
//
//	if (root == NULL)
//	{
//		return root;
//	}
//	if (search(root, x) == 0)
//	{
//		cout << "value does not exist\n";
//		return root;
//	}
//
//	else if (x < root->data)
//	{
//		root->left = deleteNode(root->left,x);
//	}
//	else if (x > root->data)
//	{
//		root->right = deleteNode(root->right, x);
//	}
//	else
//	{
//		if (root->left == NULL)
//		{
//			Treenode* temp = root->right;
//			delete root;
//			return temp;
//		}
//		if (root->right == NULL)
//		{
//			Treenode* temp = root->left;
//			delete root;
//			return temp;
//		}
//		Treenode* succ = getSuccessor(root);
//		root->data = succ->data;
//		root->right = deleteNode(root->right->right, succ->data);
//	}
//	return root;
//}
//Treenode* BinarySearchTree::getSuccessor(Treenode* c)
//{
//	c = c->right;
//	while (c != NULL && c->left != NULL)
//	{
//		c = c->left;
//	}
//	return c;
//}
//int BinarySearchTree::findHeight(Treenode* root)
//{
//	if (root == nullptr)
//	{
//		return -1;//for empty tree
//	}
//
//	int leftHeight = findHeight(root->left);
//	int rightHeight = findHeight(root->right);
//	return 1 + max(leftHeight, rightHeight);
//}
//
//void BinarySearchTree::printTree(Treenode* root, int space,int count)
//{
//	if (root == nullptr) 
//	{
//		return;
//	}
//
//	space += count;
//
//	printTree(root->right, space,count);
//
//	for (int i = count; i < space; i += 2) {
//		std::cout << "  ";
//	}
//	std::cout << root->data << "\n";
//
//	printTree(root->left, space,count);
//}
//
//void BinarySearchTree::sumAtEachLevel(int tree[], int size)
//{
//	int n = size;
//	int level = 0;
//	while (true)
//	{
//		int numNodes = pow(2, level);
//		int start = numNodes - 1;
//		int end = start + numNodes;
//		if (start >= n)
//		{
//			break;
//		}
//		int levelSum = 0;
//		for (int i = start; i < end && i < n; i++)
//		{
//			levelSum = levelSum + tree[i];
//		}
//		cout << levelSum << endl;
//		level++;
//	}
//}
//
//void BinarySearchTree::inOrder(Treenode* root)
//{
//	if (root == nullptr)
//	{
//		return;
//	}
//	inOrder(root->left);
//	cout << root->data << ", ";
//	inOrder(root->right);
//}
//void BinarySearchTree::preOrder(Treenode* root)
//{
//	if (root == nullptr)
//	{
//		return;
//	}
//	cout << root->data << ", ";
//	inOrder(root->left);
//	inOrder(root->right);
//}
//void BinarySearchTree::postOrder(Treenode* root)
//{
//	if (root == nullptr)
//	{
//		return;
//	}
//	inOrder(root->left);
//	inOrder(root->right);
//	cout << root->data << ", ";
//}