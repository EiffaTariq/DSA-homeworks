#include <iostream>
using namespace std;

class MaxHeap
{
    int* heapArray;
    int cap;
    int size;
    void mySwap(int& a, int& b)
    {
        int temp = a;
        a = b;
        b = temp;
    }
    void heapify(int i)
    {
        int max = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < size && heapArray[left] > heapArray[max]) 
        {
            max = left;
        }
        if (right < size && heapArray[right] > heapArray[max])
        {
            max = right;
        }

        if (max != i)
        {
            mySwap(heapArray[i], heapArray[max]);
            heapify(max);
        }
    }

public:
    MaxHeap(int c)
    {
        cap = c;
        size = 0;
        heapArray = new int[cap];
    }

    ~MaxHeap()
    {
        delete[] heapArray;
    }

    void insert(int value)
    {
        if (size == cap) 
        {
            cout << "Cannot insert more elements.Heap is full" << endl;
            return;
        }

        int i = size;
        heapArray[i] = value;

        while (i != 0 && heapArray[(i - 1) / 2] < heapArray[i]) 
        {
            mySwap(heapArray[i], heapArray[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
        size++;
    }

    void deleteMax() 
    {
        if (size == 0)
        {
            cout << "Cannot delete.Heap is empty" << endl;
            return;
        }
        heapArray[0] = heapArray[size - 1];
        size--;
        heapify(0);
    }

    void display()
    {
        cout << "The Heap elements are: ";
        for (int i = 0; i < size; i++)
        {
            cout << heapArray[i] << " ";
        }
        cout << '\n';
    }
};

int main() 
{
    MaxHeap mh(10);

    mh.insert(4);
    mh.insert(10);
    mh.insert(8);
    mh.display();
    mh.insert(9);
    mh.insert(12);
    mh.display();
    mh.deleteMax();
    mh.display();

    return 0;
}
