#include <iostream>
using namespace std;
class MinHeap
{
    int* heapArray;
    int cap;
    int currSize;
    void mySwap(int& a, int& b)
    {
        int temp = a;
        a = b;
        b = temp;
    }

    void heapify(int i)
    {
        int min = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < currSize && heapArray[left] < heapArray[min])
        {
            min = left;
        }

        if (right < currSize && heapArray[right] < heapArray[min])
        {
            min = right;
        }

        if (min != i)
        {
            mySwap(heapArray[i], heapArray[min]);
            heapify(min);
        }
    }

public:
    MinHeap(int c)
    {
        cap = c;
        currSize = 0;
        heapArray = new int[cap];
    }

    ~MinHeap()
    {
        delete[] heapArray;
    }

    void insert(int val) 
    {
        if (currSize == cap)
        {
            cout << "Heap is full. Cannot insert." << endl;
            return;
        }

        int i = currSize;
        heapArray[i] = val;
        currSize++;

        while (i != 0 && heapArray[(i - 1) / 2] > heapArray[i]) 
        {
            swap(heapArray[i], heapArray[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }


    void deleteMin() 
    {
        if (currSize == 0) 
        {
            cout << "Heap is empty. Cannot delete." << endl;
            return;
        }

        heapArray[0] = heapArray[currSize - 1];
        currSize--;
        heapify(0);
    }

    // Display the heap
    void display() 
    {
        for (int i = 0; i < currSize; ++i)
        {
            cout << heapArray[i] << " ";
        }
        cout << endl;
    }
};


int main()
{
    MinHeap minHeap(10);

    minHeap.insert(9);
    minHeap.insert(7);
    minHeap.insert(10);
    minHeap.insert(12);
    minHeap.insert(3);
    cout << "Elements in minimum heap are: ";
    minHeap.display();

    minHeap.deleteMin();
    cout << "Heap after deleting the minimum element is: ";
    minHeap.display();
    minHeap.deleteMin();
    minHeap.display();
    return 0;
}
