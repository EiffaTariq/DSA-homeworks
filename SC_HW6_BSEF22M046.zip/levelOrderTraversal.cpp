#include <iostream>
#include <queue>
#include"Treenode.h"
using namespace std;
void levelOrderTraversal(Treenode* root)
{
    if (root == NULL)
    {
        return;
    }
    queue<Treenode*> que;
    que.push(root);

    while (!que.empty()) 
    {
        Treenode* temp = que.front();
        que.pop();

        cout << temp->data << ", ";

        if (temp->left != NULL)
        {
            que.push(temp->left);
        }

        if (temp->right != NULL)
        {
            que.push(temp->right);
        }
    }
}

int main() 
{
    Treenode* root = new Treenode(1);
    root->left = new Treenode(2);
    root->right = new Treenode(3);
    root->left->left = new Treenode(4);
    root->left->right = new Treenode(5);
    cout << " The Level order traversal is ";
    levelOrderTraversal(root);
    cout << endl;
    return 0;
}