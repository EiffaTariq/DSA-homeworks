#include<iostream>
#ifndef NODE1_H
#define NODE1_H
using namespace std;
class Node1
{
	int data;
	Node1* next;
	friend class SLL1;
public:
	Node1(int x);
	void setData(int val);
	int getData()const
	{
		return data;
	}
};
#endif