#include<iostream>
#include "Node.h"
using namespace std;
Node::Node(int x)
{
	data = x;
	next = NULL;
	prev = NULL;
}
void Node::setData(int val)
{
	data = val;
}