#include<iostream>
#include"SLL1.h"
int main()
{
	SLL1 list1;
	list1.insertAtStart(10);//10,
	list1.insertAfter(10, 2);//10,2
	list1.insertBefore(2, 4);//10,4,2
	list1.insertAfter(2, 5);//10,4,2,5
	list1.insertAtEnd(25);//10,4,2,5,25
	list1.show();
	list1.search(6);
	list1.search(4);
	cout << "deleting the second node from the list\n";
	list1.deletekthNode(2);
	list1.show();
	list1.insertAfter(10, 2);
	list1.insertAfter(2, 2);
	list1.insertAfter(5, 2);
	list1.insertAfter(2, 2);
	list1.show();
	cout << "deleting all the 2's from the list\n";
	list1.deleteAll(2);
	list1.show();
	cout << "deleting the first occurance of 5 from the list\n";
	list1.deleteFirst(5);
	list1.show();
	return 0;
}