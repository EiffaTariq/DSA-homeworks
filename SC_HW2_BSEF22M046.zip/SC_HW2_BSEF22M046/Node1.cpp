#include<iostream>
#include "Node1.h"
using namespace std;
Node1::Node1(int x)
{
	data = x;
	next = NULL;
}
void Node1::setData(int val)
{
	data = val;
}