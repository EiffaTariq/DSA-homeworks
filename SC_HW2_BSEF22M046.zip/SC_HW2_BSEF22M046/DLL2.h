#include"Node.h"
#ifndef DLL2_h
#define DLL2_h
class DLL2
{
	Node* first;
	Node* last;
public:
	DLL2();
	Node* getFirst()const
	{
		return first;
	}
	Node* getLast()const
	{
		return last;
	}
	bool isEmpty()const
	{
		return first == nullptr;
	}
	void insertAtEnd(int val);
	void insertAtFirst(int val);
	void insertBefore(int searchedVal, int val);
	void insertAfter(int searchedVal, int val);
	void deleteFirst(int val);//also delete first
	void deleteKthNode(int k);
	void deleteAll(int val);
	void showAll()const;
	bool search(int val);
	int countAllLessThan(int val)const;
	~DLL2();
};
#endif