#include<iostream>
#include "SLL1.h"//circular
#include"Node1.h"
using namespace std;
SLL1::SLL1()
{
	first = NULL;
}
SLL1::~SLL1()
{
	Node1* temp = first;
	while (temp->next != first)
	{
		Node1* next = temp->next;
		delete temp;
		temp = next;
	}
	first = nullptr;
}
void SLL1::insertAtEnd(int val)
{
	if (first == NULL)
	{
		first = new Node1(val);
		first->next = first;
	}
	else
	{
		Node1* l = first;
		while (l->next != first)
		{
			l = l->next;
		}
		Node1* n1 = new Node1(val);
		l->next = n1;
		n1->next = first;
	}
}
void SLL1::insertAtStart(int val)
{
	if (first == NULL)
	{
		first = new Node1(val);
		first->next = first;
	}
	else
	{
		Node1* n1 = new Node1(val);
		Node1* l = first;
		while (l->next != first)
		{
			l = l->next;
		}
		l->next = first;
		n1->next = first;
		first = n1;
	}
}
void SLL1::insertBefore(int searchedVal, int val)
{
	Node1* temp = first;
	while (temp->next != first)
	{
		if (temp->data == searchedVal)
		{
			break;
		}
		temp = temp->next;
	}
	Node1* l = first;
	Node1* p = l;
	while (l->next != first)
	{
		if (l->next == first)
		{
			p = l;
		}
		l = l->next;
	}
	//searched for the node and made a last pointer
	if (temp == first)
	{
		Node1* n1 = new Node1(val);
		l->next = n1;
		n1->next = first;
		first = n1;
	}
	else if (temp == l)
	{
		Node1* n1 = new Node1(val);
		p->next = n1;
		n1->next = l;
	}
	else
	{
		Node1* n1 = new Node1(val);
		n1->next = temp->next;
		temp->next = n1;
	}
}
void SLL1::insertAfter(int searchedVal, int val)
{
	Node1* temp = first;
	while (temp->next != first)
	{
		if (temp->data == searchedVal)
		{
			break;
		}
		temp = temp->next;
	}
	Node1* l = first;
	while (l->next != first)
	{
		l = l->next;
	}
	//searched for the node and made a last pointer
	if (temp == l)//boundary case
	{
		Node1* n1 = new Node1(val);
		l->next = n1;
		n1->next = first;
	}
	else
	{
		Node1* n1 = new Node1(val);
		n1->next = temp->next;
		temp->next = n1;
	}
}
void SLL1::show()
{
	Node1* temp = first;
	Node1* l = first;
	cout << temp->data << "->";//if single node won't go in loop so for single output
	temp = temp->next;
	while (temp->next != first)
	{
		cout << temp->data << "->";
		temp = temp->next;
	}
	cout << temp->data;
	cout << "#";
	cout << "\n";
}
bool SLL1::search(int val)
{
	Node1* temp = first;
	bool found = false;
	if(temp->data == val)//if first is val
	{
		cout << "Value " << val << "found in the list\n";
		found = true;
		return found;
	}
	while (temp->next != first)
	{
		temp = temp->next;//now on second node bcuz first already checked
		if (temp->data == val)//if temp is incremented first then we can check the last node as well
		{
			cout << "Value " << val << " found in the list\n";
			found = true;
			return found;
		}
	}
	if (!found)
	{
		cout << "Value " << val << " not found in the list\n";
	} 
	return found;
}

void SLL1::deleteFirst(int val)
{
	if (isEmpty())
	{
		cout << "List is already empty" << endl;
	}
	else if (search(val) == 0)
	{
		cout << "No such value exists in the list" << endl;
	}
	else
	{
		Node1* t = first;
		Node1* prev = nullptr;
		do
		{
			if (t->data == val)
			{
				if (t == first && t->next == first)
				{
					first = nullptr;
					delete t;
					return;
				}
				prev->next = t->next;
				if (t == first)
				{
					first = t->next;
				}
				delete t;
				return;
			}
			prev = t;
			t = t->next;
		} while (t != first);
		cout << "Value " << val << " not found in the list." << endl;
	}
}

void SLL1::deleteAll(int val)
{
	if (isEmpty())
	{
		cout << "List is already empty." << endl;
		return;
	}
	Node1* temp = first;
	Node1* prev = nullptr;
	bool deleted = false;
	do
	{
		if (temp->data == val)
		{
			Node1* toBeDeleted = temp;
			if (temp == first)
			{
				if (temp->next == first)
				{
					first = nullptr;
				}
				else
				{
					first = temp->next;
					Node1* last = temp;
					while (last->next != temp)
					{
						last = last->next;
					}
					last->next = first;
				}
				temp = temp->next;
				delete toBeDeleted;
				deleted = true;
			}
			else
			{
				prev->next = temp->next;
				delete toBeDeleted;
				temp = prev->next;
				deleted = true;
			}
		}
		else
		{
			prev = temp;
			temp = temp->next;
		}
	} while (temp != first);

	if (!deleted)
	{
		cout << "Value " << val << " not found in the list." << endl;
	}
}

void SLL1::deletekthNode(int k)
{
	if (isEmpty())
	{
		cout << "There is no node to be deleted" << endl;
	}
	else
	{
		Node1* temp = first;
		Node1* prev = nullptr;
		int count = 0;
		bool deleted = false;
		do
		{
			count++;
			if (count == k)
			{
				Node1* toBeDeleted = temp;
				if (temp == first)
				{
					if (temp->next == first)
					{
						first = nullptr;
					}
					else
					{
						first = temp->next;
						Node1* last = temp;
						while (last->next != temp)
						{
							last = last->next;
						}
						last->next = first;
					}
				}
				else
				{
					prev->next = temp->next;
				}
				temp = temp->next;
				delete toBeDeleted;
				deleted = true;
				break;
			}
			prev = temp;
			temp = temp->next;
		} while (temp != first);
		if (!deleted)
		{
			cout << "There are less than " << k << " nodes in the list." << endl;
		}
	}
}
int SLL1::countAllLessThan(int val)const
{
	Node1* temp = first;
	int count = 0;
	do
	{
		if (temp->data < val)
		{
			count++;
		}
		temp = temp->next;
	} while (temp->next != first);
	if (temp->next == first && temp->data < val)//if temp is at last won't go in loop
	{
		count++;
	}
	return count;
}
