#include"Node1.h"
#ifndef SLL1_H//circular
#define SLL1_H
using namespace std;
class SLL1
{
	Node1* first;
public:
	SLL1();
	void insertAtEnd(int val);
	void insertAtStart(int val);
	void insertBefore(int searchedVal, int val);
	void insertAfter(int searchedVal, int val);
	bool isEmpty()
	{
		return (first == NULL);
	}
	Node1* getFirst()const
	{
		return first;
	}
	void show();
	void deleteFirst(int val);
	void deletekthNode(int k);
	void deleteAll(int val);
	bool search(int val);
	int countAllLessThan(int val)const;
	~SLL1();
};
#endif