#include<iostream>
#include"DLL2.h"
int main()
{
	DLL2 list1;
	list1.insertAtFirst(10);//10
	list1.insertAfter(10, 2);//10,2
	list1.showAll();
	list1.insertBefore(10, 4);//4,10,2
	list1.insertAfter(4, 5);//4,5,10,2
	list1.insertAtEnd(25);//4,5,10,2,25
	list1.showAll();
	list1.deleteFirst(5);//4,10,2,25
	list1.showAll();
	list1.deleteKthNode(2);//4,2,25
	list1.showAll();
	list1.search(10);
	list1.insertAfter(10, 4);
	list1.insertAfter(4, 4);
	list1.insertAfter(4, 4);
	list1.insertAfter(4, 4);
	list1.showAll();
	list1.deleteAll(4);
	list1.showAll();
	cout << list1.countAllLessThan(26) << "\n";
	return 0;
}