#include<iostream>
#include "DLL2.h"
#include"Node.h"
using namespace std;
DLL2::DLL2()
{
	first = NULL;
	last = NULL;
}
DLL2::~DLL2()
{
	Node* temp;
	temp = first;
	while (temp->next != first)
	{
		Node* temp2;
		temp2 = temp->next;
		delete temp;
		temp = temp2;
	}
	first = nullptr;
	last = nullptr;
}
void DLL2::insertAtEnd(int val)
{
	if (isEmpty())
	{
		Node* n1 = new Node(val);
		n1 = first;
		n1 = last;
		n1->next = first;
		n1->prev = last;
	}
	else
	{
		Node* n1 = new Node(val);
		Node* l = first;
		while (l->next != first)
		{
			l = l->next;
		}
		l->next = n1;
		n1->next = first;
		first->prev = n1;
		n1->prev = l;
		last = n1;
	}
}
void DLL2::insertAtFirst(int val)
{
	Node* n1 = new Node(val);
	if (isEmpty())
	{
		first = n1;
		last = n1;
		last->next = n1;
		first->prev = n1;
	}
	else
	{
		Node* temp = first;
		while (temp->next != first)
		{
			if (temp->data == val)
			{
				break;
			}
			temp = temp->next;
		}
		if (temp == first)
		{
			last->next = n1;
			first->prev = n1;
			n1 = first;
		}
		else
		{
			temp->prev->next = n1;
			n1->next = last;
		}
	}
}
void DLL2::insertBefore(int searchedVal, int val)
{
	bool found = false;
	Node* temp = first;
	/*do
	{
		if (temp->data == searchedVal)
		{
			found = true;
		}
		temp = temp->next;
	}while (temp->next != first);*/
	if (temp->data == searchedVal)
	{
		found = true;
	}
	while (temp->next != first && !found)
	{
		temp = temp->next;
		if (temp->data == searchedVal)
		{
			found = true;
		}
	}
	if (temp == first && found)
	{
		Node* n1 = new Node(val);
		last->next = n1;
		n1->next = first;
		first = n1;
	}
	else if (temp == last && found)
	{
		Node* n1 = new Node(val);
		last->prev->next = n1;
		n1->next = last;
	}
	else if(found)
	{
		Node* n1 = new Node(val);
		n1->next = temp->next;
		temp->next = n1;
	}
	else
	{
		cout << "The value does not exist in the list\n";
	}
}
void DLL2::insertAfter(int searchedVal, int val)
{
	bool found = false;
	Node* temp = first;
	if (temp->data == searchedVal)
	{
		found = true;
	}
	while (temp->next != first && !found)
	{
		temp = temp->next;
		if (temp->data == searchedVal)
		{
			found = true;
		}
	}
	if(temp == last && temp->data == searchedVal)
	{
		Node* n1 = new Node(val);
		last->next = n1;
		n1->next = first;
		first->prev = n1;
		last = n1;
		temp = last;
	}
	else if (temp != last && found)
	{
		Node* n1 = new Node(val);
		n1->next = temp->next;
		n1->next->prev = n1;
		n1->prev = temp;
		temp->next = n1;
	}
	else
	{
		cout << "The value does not exist in the list\n";
	}
}
void DLL2::deleteFirst(int val)
{
	if (isEmpty())
	{
		cout << "there is no node to delete\n";
	}
	else if (search(val) == 0)
	{
		cout << "The value does not exist in the list\n";
	}
	else
	{
		Node* temp = first;
		do
		{
			if (temp->data == val)
			{
				break;
			}
			temp = temp->next;
		} while (temp->next != first);
		if (temp == first)
		{
			temp = temp->next;
			last->next = temp;
			temp->prev = last;
			delete first;
			first = temp;
		}
		else if (temp->data == val && temp == last)
		{
			first->prev = temp->prev;
			temp->prev->next = first;
			delete temp;
			last = first->prev;
		}
		else
		{
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			delete temp;
		}
	}
}
void DLL2::deleteKthNode(int k)
{
	if (isEmpty())
	{
		cout << "there is no node to delete\n";
	}
	else if (k < 1)
	{
		cout << "index out of bound\n";
	}
	else
	{
		Node* temp = first;
		Node* prev = temp->prev;
		int i = 0;
		do
		{
			i++;
			if (i == k && temp != first)
			{
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
				delete temp;
				break;
			}
			else if (i == k && temp == first)
			{
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
				first = temp->next;
				delete temp;
				break;
			}
			temp = temp->next;
			prev = temp->next;
		} while (temp->next != first);
		if (temp == last && k == i + 1)
		{
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			last = temp->prev;
			delete temp;
		}
		if (k > i + 1)
		{
			cout << "index out of bound\n";
		}
	}
	

}
void DLL2::deleteAll(int val)
{
	if (isEmpty())
	{
		cout << "there is no node to delete\n";
	}
	else if (search(val) == false)
	{
		cout << "No such value exists in the node\n";
	}
	else
	{
		Node* temp = first;
		Node* curr = temp;
		do
		{
			if (temp->data == val && temp != first)
			{
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
				curr = temp;
				temp = curr->prev;
				delete curr;
			}
			else if (temp->data == val && temp == first)
			{
				temp->prev->next = temp->next;
				temp->next->prev = temp->prev;
				first = temp->next;
				curr = temp;
				temp = curr->prev;
				delete curr;
			}
			temp = temp->next;
		} while (temp->next != first);
		if (temp == last && temp->data == val)
		{
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			last = temp->prev;
			delete temp;
		}
	}
}
void DLL2::showAll()const
{
	if (isEmpty())
	{
		cout << "List is empty" << "\n";
	}
	else
	{
		Node* current = first;
		do
		{
			cout << current->data << "->";
			current = current->next;
		} while (current != first);
		cout << "#\n";
	}
}
int DLL2::countAllLessThan(int val)const
{
	Node* temp = first;
	int count = 0;
	do
	{
		if (temp->data < val)
		{
			count++;
		}
		temp = temp->next;
	} while (temp->next != first);
	if (temp == last && temp->data < val)
	{
		count++;
	}
	return count;
}
bool DLL2::search(int val)
{
	Node* temp = first;
	bool found = false;
	if (isEmpty())
	{
		found = false;
		return first;
	}
	if (temp->data == val)
	{
		found = true;
		temp = temp->next;
	}
	while (temp->next != first && !found)
	{
		temp = temp->next;
		if (temp->data == val)
		{
			found = true;
		}
	}
	return found;
}