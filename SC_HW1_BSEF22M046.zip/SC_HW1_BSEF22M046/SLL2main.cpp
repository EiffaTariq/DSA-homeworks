#include<iostream>
#include"SLL2.h"
using namespace std;
int main()
{
	SLL2 list1;
	list1.insertAtStart(10);
	list1.insertAfter(10, 5);
	list1.insertAfter(5, 5);
	list1.insertAfter(5, 5);
	list1.insertBefore(5, 15);
	list1.insertAtEnd(25);
	list1.insertAfter(15, 100);
	list1.show();
	cout << "Searching for element 50 in the list\n";
	list1.search(50);
	cout << "Searching for element 25 in the list\n";
	list1.search(25);
	cout << list1.countAllLessThan(20) << "\n";
	list1.deleteFirst();
	list1.show();
	list1.deletekthElement(100, 1);
	list1.show();
	list1.deleteAll();
	list1.show();
	list1.insertAtStart(150);
	list1.show();
	list1.~SLL2();
	list1.show();
	return 0;
}