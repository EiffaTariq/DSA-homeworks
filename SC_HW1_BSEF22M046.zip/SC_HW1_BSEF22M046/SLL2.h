#include"Node.h"
#ifndef SLL2_h
#define SLL2_h
class SLL2
{
	Node* first;
	Node* last;
public:
	SLL2();
	bool isEmpty()const;
	void insertAtEnd(int val);
	void insertAtStart(int val);
	void insertBefore(int nextVal,int val);
	void insertAfter(int prevValue,int val);
	void show()const;
	void deleteFirst();
	void deletekthElement(int val,int k);
	void deletekthNode(int k);
	void deleteAll();
	Node* search(int val);
	int countAllLessThan(int val)const;
	~SLL2();
};
#endif