#include<iostream>
#include"DLL1.h"
int main()
{
	Node n(10);
	DLL1 list1;
	list1.insertAtFirst(10);
	list1.insertAfter(5, 10);
	list1.insertAfter(5, 5);
	list1.insertAfter(5, 5);
	list1.showAll();
	list1.deleteKth(4);
	list1.showAll();
	list1.insertBefore(70,5);
	list1.showAll();
	list1.insertAtEnd(25);
	list1.insertAfter(100,25);
	list1.showAll();
	cout << "Searching for element 50 in the list\n";
	list1.search(50);
	cout << "Searching for element 25 in the list\n";
	list1.search(25);
	list1.showAll();
	cout << list1.countAllLessThan(20) << "\n";
	list1.deleteFirst();
	list1.showAll();
	list1.deleteAll();
	list1.showAll();
	list1.insertAtFirst(150);
	list1.~DLL1();
	list1.showAll();
	return 0;
}