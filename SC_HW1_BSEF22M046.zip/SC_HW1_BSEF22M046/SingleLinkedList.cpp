//#include<iostream>
//#include "SingleLinkedList.h"
//#include"Node.h"
//using namespace std;
//SingleLinkedList::SingleLinkedList()
//{
//	first = NULL;
//}
//void SingleLinkedList::insertAtEnd(int val)
//{
//	if (isEmpty())
//	{
//		Node* first = new Node(val);
//	}
//	else
//	{
//		Node* temp = first;
//		while (temp->next != NULL)
//		{
//			temp = temp->next;
//		}
//		temp->next = new Node(val);
//	}
//}
//void SingleLinkedList::insertAtStart(int val)
//{
//	if (isEmpty())
//	{
//		first = new Node(val);
//	}
//	else
//	{
//		Node* temp = new Node(val);
//		temp->next = first;
//		first = temp;
//	}
//}
//void SingleLinkedList::insertBefore(int nextVal,int val)
//{
//	if (isEmpty())
//	{
//		Node* temp = new Node(val);
//	}
//	else
//	{
//		Node* temp = first;
//		if (temp->data == nextVal)
//		{
//			Node* t1 = new Node(val);
//			t1->next = temp;
//			first = t1;
//		}
//		else
//		{
//			/*Node* actual = first;
//			while (temp->data != nextVal)
//			{
//				temp = temp->next;
//			}
//			while (first->next != temp)
//			{
//				first = first->next;
//			}
//			Node* t1 = new Node(val);
//			first->next = t1;
//			t1->next = temp;
//			first = actual;*/
//		}
//	}
//}
//void SingleLinkedList::insertAfter(int prevValue,int val)
//{
//	if (isEmpty())
//	{
//		Node* temp = new Node(val);
//	}
//	else
//	{
//		Node* temp = first;
//		while (temp->data != prevValue)
//		{
//			temp = temp->next;
//		}
//		Node* t1 = new Node(val);
//		t1->next = temp->next;
//		temp->next = t1;
//	}
//}
//bool SingleLinkedList::isEmpty()
//{
//	return(first == NULL);
//}
//void SingleLinkedList::show()
//{
//	Node* temp = first;
//	while (temp != NULL)
//	{
//		cout << temp->data << "->";
//		temp = temp->next;
//	}
//	cout << "#";
//	cout << "\n";
//}
//void SingleLinkedList::deleteFirst()
//{
//	if (isEmpty())
//	{
//		cout << "Empty\n";
//	}
//	Node* temp = first;
//	first = first->next;
//	delete temp;
//}
//void SingleLinkedList::deletekthElement(int val, int k)
//{
//	/*if (isEmpty())
//	{
//		cout << "No such element exists\n";
//	}
//	else
//	{
//		int count = 0;
//		Node* temp = first;
//		bool flag = false;
//		Node* prev = first;
//		while (temp != NULL && !flag)
//		{
//			if (temp->data == val)
//			{
//				count++;
//			}
//			if (count == k)
//			{
//				Node* t1 = temp;
//				temp = temp->next;
//				delete t1;
//				prev->next = temp;
//				flag = true;
//			}
//			prev = temp;
//			temp = temp->next;
//		}
//	}*/
//}
//void SingleLinkedList::deleteAll()
//{
//	Node* temp;
//	temp = first;
//	while (temp != NULL)
//	{
//		Node* temp2;
//		temp2 = temp;
//		temp = temp->next;
//		delete temp2;
//	}
//	first = nullptr;
//}
//void SingleLinkedList::deletekthNode(int k)
//{
//	/*Node* temp;
//	if (isEmpty() || k < 0)
//	{
//		cout << "Invalid\n";
//
//	}
//	if (k == 1)
//	{
//		deleteFirst();
//	}
//	temp = first;
//	for (int i = 1; i < k - 1;i++)
//	{
//		if (temp->next == nullptr)
//		{
//			cout << "NULL\n";
//		}
//		temp = temp->next;
//	}
//	Node* temp2;
//	temp2 = temp->next;
//	if (temp2 == nullptr)
//	{
//		cout << "NULL\n";
//	}
//	temp->next = temp2->next;
//	delete temp2;*/
//}
//Node* SingleLinkedList::search(int val)
//{
//	if (isEmpty())
//	{
//		cout << "The value is found in the linked list\n";
//		return nullptr;
//	}
//	Node* temp = first;
//	bool flag = false;
//	while (temp != NULL)
//	{
//		if (temp->data == val)
//		{
//			cout << "The value is found in the linked list\n";
//			return temp;
//		}
//		temp = temp->next;
//	}
//	cout << "The value is not present in the list\n";
//	return temp;
//}
//int SingleLinkedList::countAllLessThan(int value)const
//{
//	Node* temp = first;
//	int count = 0;
//	while (temp != NULL)
//	{
//		if (temp->data < value)
//		{
//			count++;
//		}
//		temp = temp->next;
//	}
//	cout << count << "\n";
//	return count;
//
//}
//SingleLinkedList::~SingleLinkedList()
//{
//	deleteAll();
//}