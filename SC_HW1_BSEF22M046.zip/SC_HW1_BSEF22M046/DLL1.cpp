#include<iostream>
#include "DLL1.h"
#include"Node.h"
using namespace std;
DLL1::DLL1()
{
	first = nullptr;
}
DLL1::~DLL1()
{
	deleteAll();
}
bool DLL1::isEmpty()const
{
	return first == nullptr;
}
void DLL1::insertAtEnd(int val)
{
	Node* t = new Node(val);
	Node* temp = first;
	if (isEmpty())
	{
		first = t;
	}
	else
	{
		while (temp->next != nullptr)
		{
			temp = temp->next;
		}
		temp->next = t;
		t->prev = temp;
	}
}
void DLL1::insertAtFirst(int val)
{
	Node* t = new Node(val);
	Node* temp = first;
	if (isEmpty())
	{
		first = t;
	}
	else
	{
		t->next = first;
	}
}
void DLL1::insertBefore(int val, int valueBefore)
{
	Node* t = new Node(val);
	Node* temp;
	if (isEmpty())
	{
		cout << "List is Empty\n";
	}
	temp = first;
	if (temp->data == valueBefore)
	{
		insertAtFirst(val);
	}
	while (temp != nullptr && temp->data != valueBefore)
	{
		temp = temp->next;
	}
	if (temp == nullptr)
	{
		cout << "Value not found\n";
	}
	t->prev = temp->prev;
	t->next = temp;
	if (temp->prev != nullptr)
	{
		temp->prev->next = t;
	}
	else
	{
		first = t;
	}
	temp->prev = t;
}
void DLL1::insertAfter(int val, int valueAfter)
{
	Node* t = new Node(val);
	Node* temp= first;
	while (temp != nullptr)
	{
		if (temp->data == valueAfter)
		{
			break;
		}
		temp = temp->next;
	}
	if (temp == nullptr)
	{
		cout << "Value not found\n";
	}
	else
	{
		if (temp->next != nullptr)
		{
			temp->next->prev = t;
		}
		t->next = temp->next;
		t->prev = temp;
		
		temp->next = t;
	}
}
void DLL1::deleteFirst()
{
	Node* temp;
	temp = first;
	if (isEmpty())
	{
		cout << "List is Empty\n";
	}
	first = first->next;
	if (first != nullptr)
	{
		first->prev = nullptr;
	}
	delete temp;
}
void DLL1::deleteKth(int k)
{
	Node* temp;
	if (isEmpty() || k < 0)
	{
		cout << "Invalid\n";

	}
	if (k == 1)
	{
		deleteFirst();
	}
	temp = first;
	for (int i = 1; i < k - 1; i++)
	{
		if (temp->next == nullptr)
		{
			cout << "NULL\n";
		}
		temp = temp->next;
	}
	Node* temp2;
	temp2 = temp->next;
	if (temp2 == nullptr)
	{
		cout << "NULL\n";
	}
	temp->next = temp2->next;
	delete temp2;
}

void DLL1::deleteAll()
{
	Node* temp = first;
	while (temp != nullptr)
	{
		Node* next = temp->next;
		delete temp;
		temp = next;
	}
	first = nullptr;
}
void DLL1::showAll()const
{
	Node* temp = first;
	while (temp != NULL)
	{
		cout << temp->data << "->";
		temp = temp->next;
	}
	cout << "#";
	cout << "\n";
}

int DLL1::countAllLessThan(int val)const
{
	Node* temp = first;
	int count = 0;
	while (temp != nullptr)
	{
		if (temp->data < val)
		{
			count++;
		}
		temp = temp->next;
	}
	return count;
}

Node* DLL1::search(int val)
{
	if (isEmpty())
	{
		cout << "The value is found in the linked list\n";
		return nullptr;
	}
	Node* temp = first;
	bool flag = false;
	while (temp != NULL)
	{
		if (temp->data == val)
		{
			cout << "The value is found in the linked list\n";
			return temp;
		}
		temp = temp->next;
	}
	cout << "The value is not present in the list\n";
	return temp;
}