#include<iostream>
#include "DLL2.h"
#include"Node.h"
using namespace std;
DLL2::DLL2()
{
	first = nullptr;
	last = nullptr;
}
DLL2::~DLL2()
{
	Node* temp;
	temp = first;
	while (temp != nullptr)
	{
		Node* temp2;
		temp2 = temp->next;
		delete temp;
		temp = temp2;
	}
	first = nullptr;
	last = nullptr;
}
bool DLL2::isEmpty()const
{
	return first == nullptr;
}
void DLL2::insertAtEnd(int value)
{
	Node* t = new Node(value);
	if (isEmpty())
	{
		first = t;
		last = t;
	}
	else
	{
		last->next = t;
		t->prev = last;
		last = t;
	}
}
void DLL2::insertAtFirst(int value)
{
	Node* t = new Node(value);
	if (isEmpty())
	{
		first = t;
		last = t;

	}
	else
	{
		t->next = first;
		first->prev = t;
		first = t;
	}
}
void DLL2::insertBefore(int value, int valueBefore)
{
	Node* t = new Node(value);
	if (isEmpty())
	{
		cout << "List is empty\n";
	}
	if (first->data != valueBefore)
	{
		insertAtFirst(value);
	}
	Node* temp;
	temp = first;
	while (temp != nullptr && temp->data != valueBefore)
	{
		temp = temp->next;
	}
	if (temp == nullptr)
	{
		cout << "Value not found\n";
	}
	t->prev = temp->prev;
	t->next = temp;
	if (temp->prev != nullptr)
	{
		temp->prev->next = t;
	}
	else
	{
		first = t;
	}
	temp->prev = t;
}

void DLL2::insertAfter(int value, int valueAfter)
{
	Node* t = new Node(value);
	if (isEmpty())
	{
		cout << "List is Empty\n";
	}
	Node* temp = first;
	while (temp != nullptr && temp->data != valueAfter)
	{
		temp = temp->next;
	}

	if (temp == nullptr)
	{
		cout << "Value " << valueAfter << " not found\n";
	}
	t->prev = temp;
	t->next = temp->next;
	if (temp->next != nullptr)
	{
		temp->next->prev = t;
	}
	else
	{
		last = t;
	}
	temp->next = t;

}
void DLL2::deleteFirst()
{
	Node* temp;
	temp = first;
	if (isEmpty())
	{
		cout << "List is Empty\n";
	}
	if (first == last)
	{
		first = nullptr;
		last = nullptr;
	}
	else
	{
		first = first->next;
		first->prev = nullptr;
	}
	delete temp;

}
void DLL2::deleteKth(int val, int k)
{
	Node* current = first;
	int count = 1;

	while (current != nullptr) {
		if (current->data == val) {
			if (count == k) {
				if (current == first) {
					deleteFirst();
				}
				else {
					current->prev->next = current->next;
					if (current->next) {
						current->next->prev = current->prev;
					}
					else {
						last = current->prev;
					}
					delete current;
				}
				return;
			}
			count++;
		}
		current = current->next;
	}

	cout << "Value " << val << " not found at kth position " << k << endl;
}
void DLL2::deleteAll(int val)
{
	if (isEmpty())
	{
		cout << "There is nothing to delete\n";
	}
	else
	{
		Node* current = first;
		while (current != nullptr)
		{
			Node* temp = current;
			current = current->next;
			if (temp->data == val)
			{
				if (temp == first)
				{
					first = temp->next;
					if (first)
					{
						first->prev = nullptr;
					}
				}
				else if (temp == last)
				{
					last = temp->prev;
					last->next = nullptr;
				}
				else
				{
					temp->prev->next = temp->next;
					temp->next->prev = temp->prev;
				}
				delete temp;
			}
		}
	}
}
void DLL2::showAll()const
{
	Node* temp;
	temp = first;
	while (temp != nullptr)
	{
		cout << temp->data << "->";
		temp = temp->next;
	}
	cout << "\n";
}
int DLL2::countAllLessThan(int val)const
{
	Node* temp;
	temp = first;
	int count = 0;
	while (temp != nullptr)
	{
		if (temp->data < val)
		{
			count++;
		}
		temp = temp->next;
	}
	return count;
}
Node* DLL2::search(int val)
{
	if (isEmpty())
	{
		cout << "The value is found in the linked list\n";
		return nullptr;
	}
	Node* temp = first;
	bool flag = false;
	while (temp != NULL)
	{
		if (temp->data == val)
		{
			cout << "The value is found in the linked list\n";
			return temp;
		}
		temp = temp->next;
	}
	cout << "The value is not present in the list\n";
	return temp;
}