#include<iostream>
#ifndef NODE_H
#define NODE_H
using namespace std;
class Node
{
	int data;
	Node* next;
	Node* prev;
	friend class SingleLinkedList;
	friend class SLL2;
public:
	Node(int x);
	void setData(int val);
	int getData();
};
#endif