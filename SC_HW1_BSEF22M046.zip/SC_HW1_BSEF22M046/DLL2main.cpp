#include<iostream>
#include"DLL2.h"
int main()
{
	DLL2 list1;
	list1.insertAtFirst(10);
	list1.insertAfter(15,10);
	list1.insertAfter(20, 15);
	list1.insertAfter(20, 20);
	list1.insertAfter(20,20);
	list1.insertAfter(15,20);
	list1.insertAfter(20, 20);
	list1.insertAfter(20, 20);
	list1.insertAtEnd(15);
	list1.insertAfter(50, 15);
	list1.showAll();
	list1.deleteKth(20,3);
	list1.showAll();
	cout << "Searching for element 50 in the list\n";
	list1.search(50);
	cout << "Searching for element 25 in the list\n";
	list1.search(25);
	list1.showAll();
	cout << list1.countAllLessThan(20) << "\n";
	list1.deleteFirst();
	list1.showAll();
	list1.deleteAll(20);
	list1.showAll();
	list1.insertAtFirst(150);
	list1.~DLL2();
	list1.showAll();
	return 0;
}