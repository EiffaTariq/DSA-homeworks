#include"Node.h"
#ifndef DLL2_h
#define DLL2_h
using namespace std;
class DLL2
{
	Node* first;
	Node* last;
public:
	DLL2();
	bool isEmpty()const;
	void insertAtEnd(int val);
	void insertAtFirst(int val);
	void insertBefore(int val, int valueBefore);
	void insertAfter(int val, int valueAfter);
	void deleteFirst();
	void deleteKth(int val,int k);
	void deleteAll(int val);
	void showAll()const;
	Node* search(int val);
	int countAllLessThan(int val)const;
	~DLL2();
};
#endif