//#include"Node.h"
//#ifndef SINGLELINKEDLIST
//#define SINGLELINKEDLIST
//using namespace std;
//class SingleLinkedList
//{
//	Node* first;
//public:
//	SingleLinkedList();
//	void insertAtEnd(int val);
//	void insertAtStart(int val);
//	void insertBefore(int nextVal,int val);
//	void insertAfter(int prevValue,int val);
//	bool isEmpty();
//	void show();
//	void deleteFirst();
//	void deletekthElement(int val,int k);
//	void deletekthNode(int k);
//	void deleteAll();
//	Node* search(int val);
//	int countAllLessThan(int value)const;
//	~SingleLinkedList();
//};
//#endif