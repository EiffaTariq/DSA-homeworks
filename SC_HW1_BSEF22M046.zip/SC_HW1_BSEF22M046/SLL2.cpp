#include "SLL2.h"
#include"Node.h"
#include <iostream>
SLL2::SLL2() : first(nullptr), last(nullptr) {}

bool SLL2::isEmpty() const {
    return first == nullptr;
}

void SLL2::insertAtEnd(int val)
{
    if (isEmpty())
    {
        Node* first = new Node(val);
    }
    else
    {
        Node* temp = first;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = new Node(val);
    }
}

void SLL2::insertAtStart(int val) {
    Node* newNode = new Node(val);
    if (isEmpty()) {
        first = newNode;
        last = newNode;
    }
    else {
        newNode->next = first;
        first = newNode;
    }
}

void SLL2::insertBefore(int nextVal, int val) {
    Node* newNode = new Node(val);
    if (isEmpty()) {
        cout << "List is empty, cannot insert before a value." << endl;
        return;
    }

    Node* current = first;
    Node* prev = nullptr;

    while (current != nullptr && current->data != nextVal) {
        prev = current;
        current = current->next;
    }

    if (current == nullptr) {
        cout << "Value " << nextVal << " not found in the list." << endl;
        delete newNode;
        return;
    }

    if (prev == nullptr) {
        insertAtStart(val);
    }
    else {
        newNode->next = current;
        prev->next = newNode;
    }
}

void SLL2::insertAfter(int prevValue, int val)
{
    Node* newNode = new Node(val);
    if (isEmpty()) {
        cout << "List is empty, cannot insert after a value." << endl;
        return;
    }
    Node* current = first;

    while (current != nullptr && current->data != prevValue) {
        current = current->next;
    }

    if (current == nullptr) {
        cout << "Value " << prevValue << " not found in the list." << endl;
        delete newNode;
        return;
    }

    newNode->next = current->next;
    current->next = newNode;
}

void SLL2::show() const
{
    Node* current = first;
    while (current != nullptr)
    {
        cout << current->data << "->";
        current = current->next;
    }
    cout << "#";
    cout << endl;
}

void SLL2::deleteFirst() {
    if (isEmpty()) {
        cout << "List is empty, nothing to delete." << endl;
        return;
    }

    Node* temp = first;
    first = first->next;

    if (first == nullptr) {
        last = nullptr;
    }

    delete temp;
}
void SLL2::deletekthElement(int val, int k)
{
    if (isEmpty())
    {
        cout << "No such element exists\n";
    }
    else
    {
        int count = 0;
        Node* temp = first;
        bool flag = false;
        Node* prev = first;
        while (temp != NULL && !flag)
        {
            if (temp->data == val)
            {
                count++;
            }
            if (count == k)
            {
                Node* t1 = temp;
                temp = temp->next;
                delete t1;
                prev->next = temp;
                flag = true;
            }
            prev = temp;
            temp = temp->next;
        }
    }
}
void SLL2::deletekthNode(int k)
{
    Node* temp;
    if (isEmpty() || k < 0)
    {
        cout << "Invalid\n";

    }
    else if (k == 1)
    {
        deleteFirst();
    }
    else
    {
        temp = first;
        for (int i = 1; i < k - 1; i++)
        {
            if (temp->next == nullptr)
            {
                cout << "NULL\n";
            }
            temp = temp->next;
        }
        Node* temp2;
        temp2 = temp->next;
        if (temp2 == nullptr)
        {
            cout << "NULL\n";
        }
        temp->next = temp2->next;
        delete temp2;
    }
}

void SLL2::deleteAll()
{
    while (!isEmpty())
    {
        deleteFirst();
    }
}

Node* SLL2::search(int val)
{
    if (isEmpty())
    {
        cout << "The value is found in the list\n";
        return nullptr;
    }
    Node* temp = first;
    bool flag = false;
    while (temp != NULL)
    {
        if (temp->data == val)
        {
            cout << "The value is found in the list\n";
            return temp;
        }
        temp = temp->next;
    }
    cout << "The value is not present in the list\n";
    return temp;
}

int SLL2::countAllLessThan(int val) const
{
    int count = 0;
    Node* current = first;
    while (current != nullptr)
    {
        if (current->data < val)
        {
            count++;
        }
        current = current->next;
    }
    return count;
}

SLL2::~SLL2() {
    deleteAll();
}