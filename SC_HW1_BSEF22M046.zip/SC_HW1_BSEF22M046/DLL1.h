#include"Node.h"
#ifndef DLL1_h
#define DLL1_h
using namespace std;
class DLL1
{
	Node* first;
public:
	DLL1();
	bool isEmpty()const;
	void insertAtEnd(int val);
	void insertAtFirst(int val);
	void insertBefore(int val, int valueBefore);
	void insertAfter(int val, int valueAfter);
	void deleteFirst();
	void deleteKth(int k);
	void deleteAll();
	void showAll()const;
	Node* search(int val);
	int countAllLessThan(int val)const;
	~DLL1();
};
#endif